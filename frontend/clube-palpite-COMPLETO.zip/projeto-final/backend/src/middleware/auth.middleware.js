// src/middleware/auth.middleware.js
const jwt = require('jsonwebtoken');

// ── Verifica token JWT e injeta req.user ───────────────────────
// Aceita o token via header "Authorization: Bearer ..." (padrão)
// ou via query string "?token=..." — necessário para endpoints
// carregados diretamente em <img src> (ex: QR Code), que não
// conseguem enviar headers customizados.
function autenticar(req, res, next) {
  const header = req.headers.authorization;
  let token;

  if (header && header.startsWith('Bearer ')) {
    token = header.split(' ')[1];
  } else if (req.query?.token) {
    token = req.query.token;
  }

  if (!token) {
    return res.status(401).json({ error: 'Token não fornecido.' });
  }

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.user = payload; // { id, codigoCdp, perfil }
    next();
  } catch {
    return res.status(401).json({ error: 'Token inválido ou expirado.' });
  }
}

// ── Restringe a perfil ADMIN ───────────────────────────────────
function apenasAdmin(req, res, next) {
  if (req.user?.perfil !== 'ADMIN') {
    return res.status(403).json({ error: 'Acesso restrito ao administrador.' });
  }
  next();
}

module.exports = { autenticar, apenasAdmin };
