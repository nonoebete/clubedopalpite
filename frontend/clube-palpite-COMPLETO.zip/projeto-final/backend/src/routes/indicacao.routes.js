// src/routes/indicacao.routes.js
const router = require('express').Router();
const ctrl   = require('../controllers/indicacao.controller');
const { autenticar, apenasAdmin } = require('../middleware/auth.middleware');

// ── Públicas ───────────────────────────────────────────────────
// Cadastro com ref de indicação
router.post('/cadastrar', ctrl.cadastrarComIndicacao);

// ── Autenticadas (palpiteiro logado) ───────────────────────────
router.get ('/minha-conta', autenticar, ctrl.minhaConta);
router.post('/resgatar',    autenticar, ctrl.solicitarResgate);
router.get ('/qrcode',      autenticar, ctrl.gerarQrCode); // QR Code do próprio link de indicação

// ── Admin ──────────────────────────────────────────────────────
router.get  ('/admin/indicadores',      autenticar, apenasAdmin, ctrl.listarIndicadores);
router.get  ('/admin/resgates',         autenticar, apenasAdmin, ctrl.listarResgates);
router.patch('/admin/resgates/:id',     autenticar, apenasAdmin, ctrl.atualizarResgate);
router.get  ('/admin/config',           autenticar, apenasAdmin, ctrl.getConfigIndicacao);
router.put  ('/admin/config',           autenticar, apenasAdmin, ctrl.updateConfigIndicacao);
router.get  ('/admin/qrcode/:codigoCdp', autenticar, apenasAdmin, ctrl.gerarQrCodePorCdp); // QR Code de qualquer indicador

module.exports = router;
