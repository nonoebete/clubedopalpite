#!/bin/bash
# ═══════════════════════════════════════════════════════════════
#  status-snapshot.sh — Painel de status dos snapshots
#  Uso: bash status-snapshot.sh
# ═══════════════════════════════════════════════════════════════

SNAP_DIR="/var/backups/clube-palpite"
LOG_FILE="/var/log/clube-palpite-snapshot.log"

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'
CYAN='\033[0;36m';  BOLD='\033[1m'; GRAY='\033[0;37m'; NC='\033[0m'

clear
echo -e "${BOLD}"
echo -e "╔══════════════════════════════════════════════════════════╗"
echo -e "║       Clube de Palpites · Status de Snapshots            ║"
echo -e "╚══════════════════════════════════════════════════════════╝${NC}"
echo -e "  Atualizado: $(date '+%d/%m/%Y %H:%M:%S')\n"

# ── Uso de disco ──────────────────────────────────────────────
echo -e "${CYAN}${BOLD}── DISCO ─────────────────────────────────────────────────${NC}"
TOTAL_DISCO=$(df -h / | awk 'NR==2{print $2}')
USADO_DISCO=$(df -h / | awk 'NR==2{print $3}')
LIVRE_DISCO=$(df -h / | awk 'NR==2{print $4}')
USO_PCT=$(df / | awk 'NR==2{print $5}' | tr -d '%')

# Barra de uso de disco
BARRA_CHEIA=$(( USO_PCT / 5 ))
BARRA_VAZIA=$(( 20 - BARRA_CHEIA ))
BARRA="${RED}"
[[ $USO_PCT -lt 60 ]] && BARRA="${GREEN}"
[[ $USO_PCT -ge 60 && $USO_PCT -lt 80 ]] && BARRA="${YELLOW}"

printf "  VPS: [${BARRA}"
printf '%0.s█' $(seq 1 $BARRA_CHEIA)
printf '%0.s░' $(seq 1 $BARRA_VAZIA)
printf "${NC}] ${USO_PCT}%%\n"
echo -e "  Total: ${TOTAL_DISCO} | Usado: ${USADO_DISCO} | Livre: ${LIVRE_DISCO}"

if [[ -d "$SNAP_DIR" ]]; then
  SNAP_SIZE=$(du -sh "$SNAP_DIR" 2>/dev/null | cut -f1)
  echo -e "  Snapshots: ${SNAP_SIZE} em ${SNAP_DIR}"
fi
echo ""

# ── Containers Docker ──────────────────────────────────────────
echo -e "${CYAN}${BOLD}── CONTAINERS ────────────────────────────────────────────${NC}"
if command -v docker >/dev/null 2>&1; then
  docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Image}}" 2>/dev/null \
    | while IFS= read -r linha; do
        if echo "$linha" | grep -q "Up"; then
          echo -e "  ${GREEN}${linha}${NC}"
        elif echo "$linha" | grep -q "NAME"; then
          echo -e "  ${GRAY}${linha}${NC}"
        else
          echo -e "  ${RED}${linha}${NC}"
        fi
      done
else
  echo -e "  ${YELLOW}Docker não encontrado.${NC}"
fi
echo ""

# ── Último snapshot por tipo ───────────────────────────────────
echo -e "${CYAN}${BOLD}── ÚLTIMOS SNAPSHOTS ─────────────────────────────────────${NC}"

for TIPO in mensal semanal diario; do
  PASTA="${SNAP_DIR}/${TIPO}"
  ULTIMO=$(find "$PASTA" -name "*_postgres.sql.gz" 2>/dev/null | sort -r | head -1)

  if [[ -n "$ULTIMO" ]]; then
    DATA_ARQ=$(stat -c %y "$ULTIMO" 2>/dev/null | cut -d'.' -f1)
    TAMANHO=$(du -sh "$ULTIMO" | cut -f1)
    COUNT=$(find "$PASTA" -name "*_postgres.sql.gz" 2>/dev/null | wc -l)
    echo -e "  ${GREEN}✔${NC} ${BOLD}$(printf '%-10s' ${TIPO^})${NC} — ${DATA_ARQ} | ${TAMANHO} | ${COUNT} arq."
  else
    echo -e "  ${YELLOW}○${NC} ${BOLD}$(printf '%-10s' ${TIPO^})${NC} — ${YELLOW}nenhum snapshot encontrado${NC}"
  fi
done
echo ""

# ── Próximos agendamentos (cron) ───────────────────────────────
echo -e "${CYAN}${BOLD}── AGENDAMENTOS (CRON) ───────────────────────────────────${NC}"
CRON_LINHAS=$(crontab -l 2>/dev/null | grep "snapshot" || echo "")
if [[ -n "$CRON_LINHAS" ]]; then
  echo "$CRON_LINHAS" | while IFS= read -r linha; do
    echo -e "  ${GREEN}✔${NC} ${linha}"
  done
else
  echo -e "  ${YELLOW}Nenhum cron configurado. Execute: bash instalar.sh${NC}"
fi
echo ""

# ── Últimas linhas do log ──────────────────────────────────────
echo -e "${CYAN}${BOLD}── LOG (últimas 8 linhas) ────────────────────────────────${NC}"
if [[ -f "$LOG_FILE" ]]; then
  tail -8 "$LOG_FILE" | while IFS= read -r linha; do
    if echo "$linha" | grep -q "✅\|✔"; then
      echo -e "  ${GREEN}${linha}${NC}"
    elif echo "$linha" | grep -q "✗\|erro\|Erro"; then
      echo -e "  ${RED}${linha}${NC}"
    elif echo "$linha" | grep -q "!\|warn"; then
      echo -e "  ${YELLOW}${linha}${NC}"
    else
      echo -e "  ${GRAY}${linha}${NC}"
    fi
  done
else
  echo -e "  ${GRAY}Log ainda não criado. Rode o primeiro snapshot.${NC}"
fi

echo -e "\n${GRAY}  Comandos úteis:"
echo -e "  bash snapshot.sh          → snapshot manual agora"
echo -e "  bash restaurar.sh --listar → ver todos os snapshots"
echo -e "  bash status-snapshot.sh   → atualizar este painel${NC}\n"
