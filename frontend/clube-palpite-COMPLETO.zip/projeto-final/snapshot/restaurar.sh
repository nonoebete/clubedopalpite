#!/bin/bash
# ═══════════════════════════════════════════════════════════════
#  restaurar.sh — Clube de Palpites · Restaurar snapshot
#  Uso: bash restaurar.sh [--listar] [--arquivo caminho.sql.gz]
# ═══════════════════════════════════════════════════════════════

set -euo pipefail

SNAP_DIR="/var/backups/clube-palpite"
APP_DIR="/opt/clube-palpite"
CONTAINER_POSTGRES="cdp_postgres"
DB_NAME="${POSTGRES_DB:-clube_palpite}"
DB_USER="${POSTGRES_USER:-cdp_user}"

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'
CYAN='\033[0;36m';  BOLD='\033[1m'; NC='\033[0m'

ok()   { echo -e "${GREEN}[✔] $1${NC}"; }
info() { echo -e "${CYAN}[→] $1${NC}"; }
warn() { echo -e "${YELLOW}[!] $1${NC}"; }
erro() { echo -e "${RED}[✗] $1${NC}"; exit 1; }

echo -e "\n${BOLD}╔══════════════════════════════════════════════╗"
echo -e "║   Clube de Palpites · Restaurar Snapshot      ║"
echo -e "╚══════════════════════════════════════════════╝${NC}\n"

# ── Listar snapshots disponíveis ──────────────────────────────
if [[ "${1:-}" == "--listar" || $# -eq 0 ]]; then
  echo -e "${BOLD}Snapshots disponíveis:${NC}\n"

  for TIPO in mensal semanal diario; do
    PASTA="${SNAP_DIR}/${TIPO}"
    [[ -d "$PASTA" ]] || continue
    ARQUIVOS=$(find "$PASTA" -name "*_postgres.sql.gz" | sort -r)
    [[ -z "$ARQUIVOS" ]] && continue

    echo -e "${CYAN}── ${TIPO^^} ──────────────────────────────────────${NC}"
    COUNT=0
    while IFS= read -r ARQ; do
      COUNT=$(( COUNT + 1 ))
      DATA=$(echo "$ARQ" | grep -oP '\d{8}_\d{6}' | sed 's/\(....\)\(..\)\(..\)_\(..\)\(..\)\(..\)/\3\/\2\/\1 \4:\5:\6/')
      TAMANHO=$(du -sh "$ARQ" | cut -f1)
      echo -e "  ${COUNT}. ${BOLD}$(basename "$ARQ")${NC}"
      echo -e "     📅 ${DATA} | 💾 ${TAMANHO}"
      echo -e "     📁 ${ARQ}"
      echo ""
    done <<< "$ARQUIVOS"
  done

  echo -e "Para restaurar, execute:"
  echo -e "${YELLOW}  bash restaurar.sh --arquivo /caminho/para/arquivo.sql.gz${NC}\n"
  exit 0
fi

# ── Restaurar arquivo específico ──────────────────────────────
if [[ "${1:-}" == "--arquivo" ]]; then
  ARQUIVO="${2:-}"
  [[ -z "$ARQUIVO" ]] && erro "Informe o caminho do arquivo. Ex: bash restaurar.sh --arquivo /var/backups/.../snapshot_xxx.sql.gz"
  [[ -f "$ARQUIVO" ]] || erro "Arquivo não encontrado: $ARQUIVO"

  echo -e "${RED}${BOLD}⚠️  ATENÇÃO: Isso vai SOBRESCREVER o banco atual!${NC}"
  echo -e "Arquivo: ${ARQUIVO}"
  echo -n "Tem certeza? Digite 'CONFIRMAR' para prosseguir: "
  read -r CONFIRMACAO

  [[ "$CONFIRMACAO" != "CONFIRMAR" ]] && { warn "Restauração cancelada."; exit 0; }

  # Para o backend para evitar conexões ativas
  info "Parando o backend temporariamente..."
  docker stop cdp_backend 2>/dev/null || true

  info "Restaurando banco de dados..."

  # Dropa e recria o banco
  docker exec "$CONTAINER_POSTGRES" \
    psql -U "$DB_USER" -c "DROP DATABASE IF EXISTS ${DB_NAME}_backup;" 2>/dev/null || true

  docker exec "$CONTAINER_POSTGRES" \
    psql -U "$DB_USER" -c "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname='${DB_NAME}';" 2>/dev/null || true

  # Restaura o dump
  zcat "$ARQUIVO" | docker exec -i "$CONTAINER_POSTGRES" \
    psql -U "$DB_USER" -d "$DB_NAME" 2>/dev/null

  ok "Banco restaurado com sucesso!"

  # Verifica se há arquivo de volumes correspondente
  SNAP_BASE="${ARQUIVO%_postgres.sql.gz}"
  VOL_FILE="${SNAP_BASE}_volumes.tar.gz"
  APP_FILE="${SNAP_BASE}_app.tar.gz"

  if [[ -f "$VOL_FILE" ]]; then
    echo -n "Restaurar volumes Docker também? (s/N): "
    read -r RESP_VOL
    if [[ "${RESP_VOL,,}" == "s" ]]; then
      info "Restaurando volumes Docker..."
      TMP_VOL="/tmp/cdp_restore_$(date +%s)"
      mkdir -p "$TMP_VOL"
      tar -xzf "$VOL_FILE" -C "$TMP_VOL"

      for VOL_PASTA in "$TMP_VOL"/*/; do
        VOL_NOME=$(basename "$VOL_PASTA")
        docker volume create "$VOL_NOME" 2>/dev/null || true
        docker run --rm \
          -v "${VOL_NOME}:/data" \
          -v "${VOL_PASTA}:/backup:ro" \
          alpine \
          sh -c "cp -a /backup/. /data/" 2>/dev/null || true
        ok "Volume ${VOL_NOME} restaurado."
      done
      rm -rf "$TMP_VOL"
    fi
  fi

  # Reinicia o backend
  info "Reiniciando o backend..."
  docker start cdp_backend 2>/dev/null || \
    docker compose -f "${APP_DIR}/docker-compose.yml" up -d backend

  ok "Backend reiniciado."

  echo ""
  echo -e "${GREEN}${BOLD}════════════════════════════════════════════${NC}"
  echo -e "${GREEN}${BOLD}  ✅ Restauração concluída com sucesso!${NC}"
  echo -e "${GREEN}${BOLD}════════════════════════════════════════════${NC}\n"
  exit 0
fi

erro "Uso: bash restaurar.sh [--listar] [--arquivo caminho.sql.gz]"
