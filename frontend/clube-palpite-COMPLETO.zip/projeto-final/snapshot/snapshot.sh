#!/bin/bash
# ═══════════════════════════════════════════════════════════════
#  snapshot.sh — Clube de Palpites · Snapshot completo da VPS
#  Captura: banco PostgreSQL + volumes Docker + arquivos do app
#  Retenção: diário 7 dias · semanal 4 semanas · mensal 3 meses
#
#  Uso manual:  bash snapshot.sh
#  Uso cron:    bash snapshot.sh --silencioso
# ═══════════════════════════════════════════════════════════════

set -euo pipefail

# ── Configuração ───────────────────────────────────────────────
APP_DIR="/opt/clube-palpite"           # pasta do projeto na VPS
SNAP_DIR="/var/backups/clube-palpite"  # onde salvar snapshots
LOG_FILE="/var/log/clube-palpite-snapshot.log"

CONTAINER_POSTGRES="cdp_postgres"
CONTAINER_BACKEND="cdp_backend"
DB_NAME="${POSTGRES_DB:-clube_palpite}"
DB_USER="${POSTGRES_USER:-cdp_user}"

# Retenção
MANTER_DIARIOS=7    # últimos 7 dias
MANTER_SEMANAIS=4   # últimas 4 semanas
MANTER_MENSAIS=3    # últimos 3 meses

# ── Cores ──────────────────────────────────────────────────────
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'
CYAN='\033[0;36m';  BOLD='\033[1m'; NC='\033[0m'

SILENCIOSO=false
[[ "${1:-}" == "--silencioso" ]] && SILENCIOSO=true

# ── Log ────────────────────────────────────────────────────────
log() {
  local msg="[$(date '+%Y-%m-%d %H:%M:%S')] $1"
  echo "$msg" >> "$LOG_FILE"
  $SILENCIOSO || echo -e "$1"
}
ok()   { log "${GREEN}[✔] $1${NC}"; }
info() { log "${CYAN}[→] $1${NC}"; }
warn() { log "${YELLOW}[!] $1${NC}"; }
erro() { log "${RED}[✗] $1${NC}"; exit 1; }

# ── Banner ─────────────────────────────────────────────────────
$SILENCIOSO || echo -e "\n${BOLD}╔══════════════════════════════════════════════╗"
$SILENCIOSO || echo -e "║   Clube de Palpites · Snapshot VPS completo   ║"
$SILENCIOSO || echo -e "╚══════════════════════════════════════════════╝${NC}\n"

START_TIME=$(date +%s)
TIMESTAMP=$(date '+%Y%m%d_%H%M%S')
DIA_SEMANA=$(date '+%u')   # 1=seg … 7=dom
DIA_MES=$(date '+%d')      # 01-31

# Define tipo do snapshot (para retenção diferenciada)
TIPO="diario"
[[ "$DIA_SEMANA" == "7" ]] && TIPO="semanal"   # domingo = semanal
[[ "$DIA_MES"   == "01" ]] && TIPO="mensal"    # dia 1 = mensal

SNAP_NAME="snapshot_${TIPO}_${TIMESTAMP}"
SNAP_PATH="${SNAP_DIR}/${SNAP_NAME}"

# ── 1. Garante diretórios ──────────────────────────────────────
info "Preparando diretórios..."
mkdir -p "${SNAP_DIR}/diario" "${SNAP_DIR}/semanal" "${SNAP_DIR}/mensal"
DEST="${SNAP_DIR}/${TIPO}"

# ── 2. Verifica containers ─────────────────────────────────────
info "Verificando containers Docker..."
docker inspect "$CONTAINER_POSTGRES" >/dev/null 2>&1 \
  || erro "Container $CONTAINER_POSTGRES não está rodando."
ok "Containers ativos."

# ── 3. Dump do PostgreSQL ──────────────────────────────────────
info "Fazendo dump do PostgreSQL..."
DUMP_FILE="${DEST}/${SNAP_NAME}_postgres.sql.gz"

docker exec "$CONTAINER_POSTGRES" \
  pg_dump -U "$DB_USER" "$DB_NAME" \
  | gzip -9 > "$DUMP_FILE"

DUMP_SIZE=$(du -sh "$DUMP_FILE" | cut -f1)
ok "Dump PostgreSQL salvo: ${DUMP_FILE} (${DUMP_SIZE})"

# ── 4. Snapshot dos volumes Docker ────────────────────────────
info "Capturando volumes Docker..."
VOLUMES_FILE="${DEST}/${SNAP_NAME}_volumes.tar.gz"

# Lista todos os volumes do projeto
VOLUMES=$(docker volume ls --filter "name=clube" -q 2>/dev/null || echo "")

if [[ -n "$VOLUMES" ]]; then
  # Para cada volume, extrai para um tar
  TMP_VOL="/tmp/cdp_volumes_${TIMESTAMP}"
  mkdir -p "$TMP_VOL"

  for VOL in $VOLUMES; do
    VOL_DIR="${TMP_VOL}/${VOL}"
    mkdir -p "$VOL_DIR"
    docker run --rm \
      -v "${VOL}:/data:ro" \
      -v "${TMP_VOL}:/backup" \
      alpine \
      sh -c "cp -a /data/. /backup/${VOL}/" 2>/dev/null || true
  done

  tar -czf "$VOLUMES_FILE" -C "$TMP_VOL" .
  rm -rf "$TMP_VOL"
  VOL_SIZE=$(du -sh "$VOLUMES_FILE" | cut -f1)
  ok "Volumes Docker salvos: ${VOLUMES_FILE} (${VOL_SIZE})"
else
  warn "Nenhum volume Docker encontrado com prefixo 'clube'."
fi

# ── 5. Snapshot dos arquivos do app ───────────────────────────
info "Copiando arquivos do app..."
APP_FILE="${DEST}/${SNAP_NAME}_app.tar.gz"

tar -czf "$APP_FILE" \
  --exclude="${APP_DIR}/node_modules" \
  --exclude="${APP_DIR}/.git" \
  --exclude="${APP_DIR}/backend/node_modules" \
  -C "$(dirname "$APP_DIR")" \
  "$(basename "$APP_DIR")" 2>/dev/null || true

APP_SIZE=$(du -sh "$APP_FILE" | cut -f1)
ok "Arquivos do app salvos: ${APP_FILE} (${APP_SIZE})"

# ── 6. Gera manifesto do snapshot ─────────────────────────────
info "Gerando manifesto..."
MANIFEST="${DEST}/${SNAP_NAME}_manifesto.txt"

cat > "$MANIFEST" <<EOF
═══════════════════════════════════════════════════
  Clube de Palpites · Manifesto de Snapshot
═══════════════════════════════════════════════════
Data/hora:      $(date '+%d/%m/%Y %H:%M:%S')
Tipo:           ${TIPO}
Hostname:       $(hostname)
Uptime:         $(uptime -p)

── Arquivos gerados ─────────────────────────────
$(ls -lh "${DEST}/${SNAP_NAME}"* 2>/dev/null | awk '{print $5, $9}')

── Banco de dados ───────────────────────────────
Container:      ${CONTAINER_POSTGRES}
Database:       ${DB_NAME}
Tamanho dump:   ${DUMP_SIZE}

── Docker ───────────────────────────────────────
$(docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Image}}" 2>/dev/null || echo "N/A")

── Disco (uso atual) ────────────────────────────
$(df -h / | tail -1)

── Snapshots armazenados ────────────────────────
$(find "${SNAP_DIR}" -name "*.sql.gz" | wc -l) arquivos de banco
$(du -sh "${SNAP_DIR}" 2>/dev/null | cut -f1) total em disco
═══════════════════════════════════════════════════
EOF

ok "Manifesto: ${MANIFEST}"

# ── 7. Limpeza por retenção ────────────────────────────────────
info "Aplicando política de retenção..."

limpar() {
  local pasta="$1" manter="$2" tipo="$3"
  local count
  count=$(find "$pasta" -name "*_postgres.sql.gz" | wc -l)
  if [[ $count -gt $manter ]]; then
    local excesso=$(( count - manter ))
    find "$pasta" -name "${SNAP_NAME%_*}*" -printf '%T+ %p\n' 2>/dev/null \
      | sort | head -n "$excesso" \
      | awk '{print $2}' \
      | xargs -r rm -f
    ok "Retenção ${tipo}: removidos ${excesso} snapshot(s) antigos (mantendo ${manter})."
  else
    ok "Retenção ${tipo}: ${count}/${manter} snapshots (sem remoção necessária)."
  fi
}

# Remove por tipo, mantendo dumps mais recentes
find "${SNAP_DIR}/diario"  -name "*_postgres.sql.gz" | sort | head -n -${MANTER_DIARIOS}  | xargs -r rm -f 2>/dev/null || true
find "${SNAP_DIR}/diario"  -name "*_volumes.tar.gz"  | sort | head -n -${MANTER_DIARIOS}  | xargs -r rm -f 2>/dev/null || true
find "${SNAP_DIR}/diario"  -name "*_app.tar.gz"      | sort | head -n -${MANTER_DIARIOS}  | xargs -r rm -f 2>/dev/null || true
find "${SNAP_DIR}/semanal" -name "*_postgres.sql.gz" | sort | head -n -${MANTER_SEMANAIS} | xargs -r rm -f 2>/dev/null || true
find "${SNAP_DIR}/mensal"  -name "*_postgres.sql.gz" | sort | head -n -${MANTER_MENSAIS}  | xargs -r rm -f 2>/dev/null || true

ok "Política de retenção aplicada."

# ── 8. Resumo final ────────────────────────────────────────────
END_TIME=$(date +%s)
DURACAO=$(( END_TIME - START_TIME ))
TOTAL_SNAP=$(du -sh "${SNAP_DIR}" 2>/dev/null | cut -f1)

$SILENCIOSO || echo ""
$SILENCIOSO || echo -e "${GREEN}${BOLD}════════════════════════════════════════════${NC}"
$SILENCIOSO || echo -e "${GREEN}${BOLD}  ✅ Snapshot concluído em ${DURACAO}s${NC}"
$SILENCIOSO || echo -e "${GREEN}${BOLD}  📦 Tipo: ${TIPO} | Pasta: ${DEST}${NC}"
$SILENCIOSO || echo -e "${GREEN}${BOLD}  💾 Total em disco: ${TOTAL_SNAP}${NC}"
$SILENCIOSO || echo -e "${GREEN}${BOLD}════════════════════════════════════════════${NC}\n"

log "✅ Snapshot ${SNAP_NAME} concluído em ${DURACAO}s. Total: ${TOTAL_SNAP}"
exit 0
