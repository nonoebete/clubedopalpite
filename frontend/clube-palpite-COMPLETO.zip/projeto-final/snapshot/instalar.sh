#!/bin/bash
# ═══════════════════════════════════════════════════════════════
#  instalar.sh — Ativa o sistema de snapshots na VPS
#  Executa UMA VEZ no servidor: bash instalar.sh
# ═══════════════════════════════════════════════════════════════

set -euo pipefail

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'
CYAN='\033[0;36m';  BOLD='\033[1m'; NC='\033[0m'

ok()   { echo -e "${GREEN}[✔] $1${NC}"; }
info() { echo -e "${CYAN}[→] $1${NC}"; }
warn() { echo -e "${YELLOW}[!] $1${NC}"; }
erro() { echo -e "${RED}[✗] $1${NC}"; exit 1; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SNAP_DIR="/var/backups/clube-palpite"
LOG_FILE="/var/log/clube-palpite-snapshot.log"
INSTALL_DIR="/opt/snapshot-cdp"

echo -e "\n${BOLD}╔══════════════════════════════════════════════╗"
echo -e "║  Clube de Palpites · Instalando Snapshots     ║"
echo -e "╚══════════════════════════════════════════════╝${NC}\n"

# ── 1. Verifica root ───────────────────────────────────────────
[[ $EUID -ne 0 ]] && erro "Execute como root: sudo bash instalar.sh"

# ── 2. Cria diretórios ─────────────────────────────────────────
info "Criando diretórios..."
mkdir -p "${SNAP_DIR}/diario" "${SNAP_DIR}/semanal" "${SNAP_DIR}/mensal"
touch "$LOG_FILE"
chmod 640 "$LOG_FILE"
ok "Diretórios criados em ${SNAP_DIR}"

# ── 3. Instala scripts no sistema ─────────────────────────────
info "Instalando scripts em ${INSTALL_DIR}..."
mkdir -p "$INSTALL_DIR"

cp "${SCRIPT_DIR}/snapshot.sh"       "${INSTALL_DIR}/"
cp "${SCRIPT_DIR}/restaurar.sh"      "${INSTALL_DIR}/"
cp "${SCRIPT_DIR}/status-snapshot.sh" "${INSTALL_DIR}/"

chmod +x "${INSTALL_DIR}/snapshot.sh"
chmod +x "${INSTALL_DIR}/restaurar.sh"
chmod +x "${INSTALL_DIR}/status-snapshot.sh"

# Cria atalhos globais
ln -sf "${INSTALL_DIR}/snapshot.sh"        /usr/local/bin/cdp-snapshot
ln -sf "${INSTALL_DIR}/restaurar.sh"       /usr/local/bin/cdp-restaurar
ln -sf "${INSTALL_DIR}/status-snapshot.sh" /usr/local/bin/cdp-status

ok "Comandos disponíveis: cdp-snapshot, cdp-restaurar, cdp-status"

# ── 4. Configura cron ──────────────────────────────────────────
info "Configurando agendamentos cron..."

# Remove entradas antigas do clube-palpite
crontab -l 2>/dev/null | grep -v "snapshot.sh" | crontab - 2>/dev/null || true

# Adiciona novos agendamentos
(crontab -l 2>/dev/null; cat <<'CRON'
# ── Clube de Palpites · Snapshots automáticos ──────────────────
# Diário: todo dia às 02:00 (exceto dom e dia 1)
0 2 2-31 * 1-6 bash /opt/snapshot-cdp/snapshot.sh --silencioso

# Semanal: todo domingo às 02:00
0 2 * * 0 bash /opt/snapshot-cdp/snapshot.sh --silencioso

# Mensal: todo dia 1 às 02:00
0 2 1 * * bash /opt/snapshot-cdp/snapshot.sh --silencioso
CRON
) | crontab -

ok "Cron configurado:"
echo -e "  ${CYAN}02:00 todo dia      ${NC}→ snapshot diário (retém 7)"
echo -e "  ${CYAN}02:00 todo domingo  ${NC}→ snapshot semanal (retém 4)"
echo -e "  ${CYAN}02:00 todo dia 1    ${NC}→ snapshot mensal (retém 3)"

# ── 5. Carrega variáveis do .env se existir ───────────────────
ENV_FILE="/opt/clube-palpite/.env"
if [[ -f "$ENV_FILE" ]]; then
  info "Carregando variáveis do .env do projeto..."
  # Adiciona as vars ao cron environment
  (crontab -l 2>/dev/null | head -1 | grep -q "^POSTGRES" ) || \
  (
    VARS=$(grep -E "^POSTGRES_" "$ENV_FILE" | tr '\n' ' ')
    CRON_ATUAL=$(crontab -l 2>/dev/null)
    echo "$VARS" > /tmp/cron_env
    echo "$CRON_ATUAL" >> /tmp/cron_env
    crontab /tmp/cron_env
    rm -f /tmp/cron_env
  ) 2>/dev/null || true
  ok ".env carregado."
else
  warn ".env não encontrado em ${ENV_FILE}. As variáveis POSTGRES_DB/USER serão os valores padrão."
fi

# ── 6. Roda o primeiro snapshot agora ─────────────────────────
echo ""
echo -n "Rodar o primeiro snapshot agora? (S/n): "
read -r RESP

if [[ "${RESP,,}" != "n" ]]; then
  info "Rodando snapshot inicial..."
  bash "${INSTALL_DIR}/snapshot.sh"
else
  warn "Pulando snapshot inicial. O primeiro será automático às 02:00."
fi

# ── 7. Resumo ──────────────────────────────────────────────────
echo ""
echo -e "${GREEN}${BOLD}════════════════════════════════════════════════${NC}"
echo -e "${GREEN}${BOLD}  ✅ Sistema de snapshots instalado com sucesso!${NC}"
echo -e "${GREEN}${BOLD}════════════════════════════════════════════════${NC}"
echo ""
echo -e "  ${BOLD}Comandos disponíveis em qualquer lugar:${NC}"
echo -e "  ${CYAN}cdp-snapshot${NC}           → fazer snapshot agora"
echo -e "  ${CYAN}cdp-restaurar --listar${NC} → ver snapshots disponíveis"
echo -e "  ${CYAN}cdp-status${NC}             → painel de status"
echo ""
echo -e "  ${BOLD}Snapshots salvos em:${NC} ${SNAP_DIR}"
echo -e "  ${BOLD}Log em:${NC} ${LOG_FILE}"
echo ""
